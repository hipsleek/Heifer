effect Foo0 : (unit -> unit)
effect Foo1 : (unit -> unit)
effect Foo2 : (unit -> unit)
effect Foo3 : (unit -> unit)
effect Foo4 : (unit -> unit)
effect Foo5 : (unit -> unit)
effect Foo6 : (unit -> unit)
effect Foo7 : (unit -> unit)
effect Foo8 : (unit -> unit)
effect Foo9 : (unit -> unit)
effect Foo10 : (unit -> unit)
effect Foo11 : (unit -> unit)
effect Foo12 : (unit -> unit)
effect Foo13 : (unit -> unit)
effect Foo14 : (unit -> unit)
effect Foo15 : (unit -> unit)
effect Foo16 : (unit -> unit)
effect Foo17 : (unit -> unit)
effect Foo18 : (unit -> unit)
effect Foo19 : (unit -> unit)
effect Foo20 : (unit -> unit)
effect Foo21 : (unit -> unit)
effect Foo22 : (unit -> unit)
effect Foo23 : (unit -> unit)
effect Foo24 : (unit -> unit)
effect Foo25 : (unit -> unit)
effect Foo26 : (unit -> unit)
effect Foo27 : (unit -> unit)
effect Foo28 : (unit -> unit)
effect Foo29 : (unit -> unit)
effect Foo30 : (unit -> unit)
effect Foo31 : (unit -> unit)
effect Foo32 : (unit -> unit)
effect Foo33 : (unit -> unit)
effect Foo34 : (unit -> unit)
effect Foo35 : (unit -> unit)
effect Foo36 : (unit -> unit)
effect Foo37 : (unit -> unit)
effect Foo38 : (unit -> unit)
effect Foo39 : (unit -> unit)
effect Foo40 : (unit -> unit)
effect Foo41 : (unit -> unit)
effect Foo42 : (unit -> unit)
effect Foo43 : (unit -> unit)
effect Foo44 : (unit -> unit)
effect Foo45 : (unit -> unit)
effect Foo46 : (unit -> unit)
effect Foo47 : (unit -> unit)
effect Foo48 : (unit -> unit)
effect Foo49 : (unit -> unit)
effect Foo50 : (unit -> unit)
effect Foo51 : (unit -> unit)
effect Foo52 : (unit -> unit)
effect Foo53 : (unit -> unit)
effect Foo54 : (unit -> unit)
effect Foo55 : (unit -> unit)
effect Foo56 : (unit -> unit)
effect Foo57 : (unit -> unit)
effect Foo58 : (unit -> unit)
effect Foo59 : (unit -> unit)
effect Foo60 : (unit -> unit)
effect Foo61 : (unit -> unit)
effect Foo62 : (unit -> unit)
effect Foo63 : (unit -> unit)
effect Foo64 : (unit -> unit)
effect Foo65 : (unit -> unit)
effect Foo66 : (unit -> unit)
effect Foo67 : (unit -> unit)
effect Foo68 : (unit -> unit)
effect Foo69 : (unit -> unit)
effect Foo70 : (unit -> unit)
effect Foo71 : (unit -> unit)
effect Foo72 : (unit -> unit)
effect Foo73 : (unit -> unit)
effect Foo74 : (unit -> unit)
effect Foo75 : (unit -> unit)
effect Foo76 : (unit -> unit)
effect Foo77 : (unit -> unit)
effect Foo78 : (unit -> unit)
effect Foo79 : (unit -> unit)
effect Foo80 : (unit -> unit)
effect Foo81 : (unit -> unit)
effect Foo82 : (unit -> unit)
effect Foo83 : (unit -> unit)
effect Foo84 : (unit -> unit)
effect Foo85 : (unit -> unit)
effect Foo86 : (unit -> unit)
effect Foo87 : (unit -> unit)
effect Foo88 : (unit -> unit)
effect Foo89 : (unit -> unit)
effect Foo90 : (unit -> unit)
effect Foo91 : (unit -> unit)
effect Foo92 : (unit -> unit)
effect Foo93 : (unit -> unit)
effect Foo94 : (unit -> unit)
effect Foo95 : (unit -> unit)
effect Foo96 : (unit -> unit)
effect Foo97 : (unit -> unit)
effect Foo98 : (unit -> unit)
effect Foo99 : (unit -> unit)
effect Foo100 : (unit -> unit)
effect Foo101 : (unit -> unit)
effect Foo102 : (unit -> unit)
effect Foo103 : (unit -> unit)
effect Foo104 : (unit -> unit)
effect Foo105 : (unit -> unit)
effect Foo106 : (unit -> unit)
effect Foo107 : (unit -> unit)
effect Foo108 : (unit -> unit)
effect Foo109 : (unit -> unit)
effect Foo110 : (unit -> unit)
effect Foo111 : (unit -> unit)
effect Foo112 : (unit -> unit)
effect Foo113 : (unit -> unit)
effect Foo114 : (unit -> unit)
effect Foo115 : (unit -> unit)
effect Foo116 : (unit -> unit)
effect Foo117 : (unit -> unit)
effect Foo118 : (unit -> unit)
effect Foo119 : (unit -> unit)
effect Foo120 : (unit -> unit)
effect Foo121 : (unit -> unit)
effect Foo122 : (unit -> unit)
effect Foo123 : (unit -> unit)
effect Foo124 : (unit -> unit)
effect Foo125 : (unit -> unit)
effect Foo126 : (unit -> unit)
effect Foo127 : (unit -> unit)
effect Foo128 : (unit -> unit)
effect Foo129 : (unit -> unit)
effect Foo130 : (unit -> unit)
effect Foo131 : (unit -> unit)
effect Foo132 : (unit -> unit)
effect Foo133 : (unit -> unit)
effect Foo134 : (unit -> unit)
effect Foo135 : (unit -> unit)
effect Foo136 : (unit -> unit)
effect Foo137 : (unit -> unit)
effect Foo138 : (unit -> unit)
effect Foo139 : (unit -> unit)
effect Foo140 : (unit -> unit)
effect Foo141 : (unit -> unit)
effect Foo142 : (unit -> unit)
effect Foo143 : (unit -> unit)
effect Foo144 : (unit -> unit)
effect Foo145 : (unit -> unit)
effect Foo146 : (unit -> unit)
effect Foo147 : (unit -> unit)
effect Foo148 : (unit -> unit)
effect Foo149 : (unit -> unit)
effect Foo150 : (unit -> unit)
effect Foo151 : (unit -> unit)
effect Foo152 : (unit -> unit)
effect Foo153 : (unit -> unit)
effect Foo154 : (unit -> unit)
effect Foo155 : (unit -> unit)
effect Foo156 : (unit -> unit)
effect Foo157 : (unit -> unit)
effect Foo158 : (unit -> unit)
effect Foo159 : (unit -> unit)
effect Foo160 : (unit -> unit)
effect Foo161 : (unit -> unit)
effect Foo162 : (unit -> unit)
effect Foo163 : (unit -> unit)
effect Foo164 : (unit -> unit)
effect Foo165 : (unit -> unit)
effect Foo166 : (unit -> unit)
effect Foo167 : (unit -> unit)
effect Foo168 : (unit -> unit)
effect Foo169 : (unit -> unit)
effect Foo170 : (unit -> unit)
effect Foo171 : (unit -> unit)
effect Foo172 : (unit -> unit)
effect Foo173 : (unit -> unit)
effect Foo174 : (unit -> unit)
effect Foo175 : (unit -> unit)
effect Foo176 : (unit -> unit)
effect Foo177 : (unit -> unit)
effect Foo178 : (unit -> unit)
effect Foo179 : (unit -> unit)
effect Foo180 : (unit -> unit)
effect Foo181 : (unit -> unit)
effect Foo182 : (unit -> unit)
effect Foo183 : (unit -> unit)
effect Foo184 : (unit -> unit)
effect Foo185 : (unit -> unit)
effect Foo186 : (unit -> unit)
effect Foo187 : (unit -> unit)
effect Foo188 : (unit -> unit)
effect Foo189 : (unit -> unit)
effect Foo190 : (unit -> unit)
effect Foo191 : (unit -> unit)
effect Foo192 : (unit -> unit)
effect Foo193 : (unit -> unit)
effect Foo194 : (unit -> unit)
effect Foo195 : (unit -> unit)
effect Foo196 : (unit -> unit)
effect Foo197 : (unit -> unit)
effect Foo198 : (unit -> unit)
effect Foo199 : (unit -> unit)
effect Foo200 : (unit -> unit)
effect Foo201 : (unit -> unit)
effect Foo202 : (unit -> unit)
effect Foo203 : (unit -> unit)
effect Foo204 : (unit -> unit)
effect Foo205 : (unit -> unit)
effect Foo206 : (unit -> unit)
effect Foo207 : (unit -> unit)
effect Foo208 : (unit -> unit)
effect Foo209 : (unit -> unit)
effect Foo210 : (unit -> unit)
effect Foo211 : (unit -> unit)
effect Foo212 : (unit -> unit)
effect Foo213 : (unit -> unit)
effect Foo214 : (unit -> unit)
effect Foo215 : (unit -> unit)
effect Foo216 : (unit -> unit)
effect Foo217 : (unit -> unit)
effect Foo218 : (unit -> unit)
effect Foo219 : (unit -> unit)
effect Foo220 : (unit -> unit)
effect Foo221 : (unit -> unit)
effect Foo222 : (unit -> unit)
effect Foo223 : (unit -> unit)
effect Foo224 : (unit -> unit)
effect Foo225 : (unit -> unit)
effect Foo226 : (unit -> unit)
effect Foo227 : (unit -> unit)
effect Foo228 : (unit -> unit)
effect Foo229 : (unit -> unit)
effect Foo230 : (unit -> unit)
effect Foo231 : (unit -> unit)
effect Foo232 : (unit -> unit)
effect Foo233 : (unit -> unit)
effect Foo234 : (unit -> unit)
effect Foo235 : (unit -> unit)
effect Foo236 : (unit -> unit)
effect Foo237 : (unit -> unit)
effect Foo238 : (unit -> unit)
effect Foo239 : (unit -> unit)
effect Foo240 : (unit -> unit)
effect Foo241 : (unit -> unit)
effect Foo242 : (unit -> unit)
effect Foo243 : (unit -> unit)
effect Foo244 : (unit -> unit)
effect Foo245 : (unit -> unit)
effect Foo246 : (unit -> unit)
effect Foo247 : (unit -> unit)
effect Foo248 : (unit -> unit)
effect Foo249 : (unit -> unit)
effect Foo250 : (unit -> unit)
effect Foo251 : (unit -> unit)
effect Foo252 : (unit -> unit)
effect Foo253 : (unit -> unit)
effect Foo254 : (unit -> unit)

let stress f
(*@ requires _^*, eff(f)= (_^* ) -> Foo0.Q(Foo0()) @*)
(*@ ensures  ((((((((Foo0.Foo1.Foo3.Foo7.Foo15.Foo31.Foo63.Foo127) \/ (Foo0.Foo1.Foo3.Foo7.Foo15.Foo31.Foo63.Foo128)) \/ ((Foo0.Foo1.Foo3.Foo7.Foo15.Foo31.Foo64.Foo129) \/ (Foo0.Foo1.Foo3.Foo7.Foo15.Foo31.Foo64.Foo130))) \/ (((Foo0.Foo1.Foo3.Foo7.Foo15.Foo32.Foo65.Foo131) \/ (Foo0.Foo1.Foo3.Foo7.Foo15.Foo32.Foo65.Foo132)) \/ ((Foo0.Foo1.Foo3.Foo7.Foo15.Foo32.Foo66.Foo133) \/ (Foo0.Foo1.Foo3.Foo7.Foo15.Foo32.Foo66.Foo134)))) \/ ((((Foo0.Foo1.Foo3.Foo7.Foo16.Foo33.Foo67.Foo135) \/ (Foo0.Foo1.Foo3.Foo7.Foo16.Foo33.Foo67.Foo136)) \/ ((Foo0.Foo1.Foo3.Foo7.Foo16.Foo33.Foo68.Foo137) \/ (Foo0.Foo1.Foo3.Foo7.Foo16.Foo33.Foo68.Foo138))) \/ (((Foo0.Foo1.Foo3.Foo7.Foo16.Foo34.Foo69.Foo139) \/ (Foo0.Foo1.Foo3.Foo7.Foo16.Foo34.Foo69.Foo140)) \/ ((Foo0.Foo1.Foo3.Foo7.Foo16.Foo34.Foo70.Foo141) \/ (Foo0.Foo1.Foo3.Foo7.Foo16.Foo34.Foo70.Foo142))))) \/ (((((Foo0.Foo1.Foo3.Foo8.Foo17.Foo35.Foo71.Foo143) \/ (Foo0.Foo1.Foo3.Foo8.Foo17.Foo35.Foo71.Foo144)) \/ ((Foo0.Foo1.Foo3.Foo8.Foo17.Foo35.Foo72.Foo145) \/ (Foo0.Foo1.Foo3.Foo8.Foo17.Foo35.Foo72.Foo146))) \/ (((Foo0.Foo1.Foo3.Foo8.Foo17.Foo36.Foo73.Foo147) \/ (Foo0.Foo1.Foo3.Foo8.Foo17.Foo36.Foo73.Foo148)) \/ ((Foo0.Foo1.Foo3.Foo8.Foo17.Foo36.Foo74.Foo149) \/ (Foo0.Foo1.Foo3.Foo8.Foo17.Foo36.Foo74.Foo150)))) \/ ((((Foo0.Foo1.Foo3.Foo8.Foo18.Foo37.Foo75.Foo151) \/ (Foo0.Foo1.Foo3.Foo8.Foo18.Foo37.Foo75.Foo152)) \/ ((Foo0.Foo1.Foo3.Foo8.Foo18.Foo37.Foo76.Foo153) \/ (Foo0.Foo1.Foo3.Foo8.Foo18.Foo37.Foo76.Foo154))) \/ (((Foo0.Foo1.Foo3.Foo8.Foo18.Foo38.Foo77.Foo155) \/ (Foo0.Foo1.Foo3.Foo8.Foo18.Foo38.Foo77.Foo156)) \/ ((Foo0.Foo1.Foo3.Foo8.Foo18.Foo38.Foo78.Foo157) \/ (Foo0.Foo1.Foo3.Foo8.Foo18.Foo38.Foo78.Foo158)))))) \/ ((((((Foo0.Foo1.Foo4.Foo9.Foo19.Foo39.Foo79.Foo159) \/ (Foo0.Foo1.Foo4.Foo9.Foo19.Foo39.Foo79.Foo160)) \/ ((Foo0.Foo1.Foo4.Foo9.Foo19.Foo39.Foo80.Foo161) \/ (Foo0.Foo1.Foo4.Foo9.Foo19.Foo39.Foo80.Foo162))) \/ (((Foo0.Foo1.Foo4.Foo9.Foo19.Foo40.Foo81.Foo163) \/ (Foo0.Foo1.Foo4.Foo9.Foo19.Foo40.Foo81.Foo164)) \/ ((Foo0.Foo1.Foo4.Foo9.Foo19.Foo40.Foo82.Foo165) \/ (Foo0.Foo1.Foo4.Foo9.Foo19.Foo40.Foo82.Foo166)))) \/ ((((Foo0.Foo1.Foo4.Foo9.Foo20.Foo41.Foo83.Foo167) \/ (Foo0.Foo1.Foo4.Foo9.Foo20.Foo41.Foo83.Foo168)) \/ ((Foo0.Foo1.Foo4.Foo9.Foo20.Foo41.Foo84.Foo169) \/ (Foo0.Foo1.Foo4.Foo9.Foo20.Foo41.Foo84.Foo170))) \/ (((Foo0.Foo1.Foo4.Foo9.Foo20.Foo42.Foo85.Foo171) \/ (Foo0.Foo1.Foo4.Foo9.Foo20.Foo42.Foo85.Foo172)) \/ ((Foo0.Foo1.Foo4.Foo9.Foo20.Foo42.Foo86.Foo173) \/ (Foo0.Foo1.Foo4.Foo9.Foo20.Foo42.Foo86.Foo174))))) \/ (((((Foo0.Foo1.Foo4.Foo10.Foo21.Foo43.Foo87.Foo175) \/ (Foo0.Foo1.Foo4.Foo10.Foo21.Foo43.Foo87.Foo176)) \/ ((Foo0.Foo1.Foo4.Foo10.Foo21.Foo43.Foo88.Foo177) \/ (Foo0.Foo1.Foo4.Foo10.Foo21.Foo43.Foo88.Foo178))) \/ (((Foo0.Foo1.Foo4.Foo10.Foo21.Foo44.Foo89.Foo179) \/ (Foo0.Foo1.Foo4.Foo10.Foo21.Foo44.Foo89.Foo180)) \/ ((Foo0.Foo1.Foo4.Foo10.Foo21.Foo44.Foo90.Foo181) \/ (Foo0.Foo1.Foo4.Foo10.Foo21.Foo44.Foo90.Foo182)))) \/ ((((Foo0.Foo1.Foo4.Foo10.Foo22.Foo45.Foo91.Foo183) \/ (Foo0.Foo1.Foo4.Foo10.Foo22.Foo45.Foo91.Foo184)) \/ ((Foo0.Foo1.Foo4.Foo10.Foo22.Foo45.Foo92.Foo185) \/ (Foo0.Foo1.Foo4.Foo10.Foo22.Foo45.Foo92.Foo186))) \/ (((Foo0.Foo1.Foo4.Foo10.Foo22.Foo46.Foo93.Foo187) \/ (Foo0.Foo1.Foo4.Foo10.Foo22.Foo46.Foo93.Foo188)) \/ ((Foo0.Foo1.Foo4.Foo10.Foo22.Foo46.Foo94.Foo189) \/ (Foo0.Foo1.Foo4.Foo10.Foo22.Foo46.Foo94.Foo190))))))) \/ (((((((Foo0.Foo2.Foo5.Foo11.Foo23.Foo47.Foo95.Foo191) \/ (Foo0.Foo2.Foo5.Foo11.Foo23.Foo47.Foo95.Foo192)) \/ ((Foo0.Foo2.Foo5.Foo11.Foo23.Foo47.Foo96.Foo193) \/ (Foo0.Foo2.Foo5.Foo11.Foo23.Foo47.Foo96.Foo194))) \/ (((Foo0.Foo2.Foo5.Foo11.Foo23.Foo48.Foo97.Foo195) \/ (Foo0.Foo2.Foo5.Foo11.Foo23.Foo48.Foo97.Foo196)) \/ ((Foo0.Foo2.Foo5.Foo11.Foo23.Foo48.Foo98.Foo197) \/ (Foo0.Foo2.Foo5.Foo11.Foo23.Foo48.Foo98.Foo198)))) \/ ((((Foo0.Foo2.Foo5.Foo11.Foo24.Foo49.Foo99.Foo199) \/ (Foo0.Foo2.Foo5.Foo11.Foo24.Foo49.Foo99.Foo200)) \/ ((Foo0.Foo2.Foo5.Foo11.Foo24.Foo49.Foo100.Foo201) \/ (Foo0.Foo2.Foo5.Foo11.Foo24.Foo49.Foo100.Foo202))) \/ (((Foo0.Foo2.Foo5.Foo11.Foo24.Foo50.Foo101.Foo203) \/ (Foo0.Foo2.Foo5.Foo11.Foo24.Foo50.Foo101.Foo204)) \/ ((Foo0.Foo2.Foo5.Foo11.Foo24.Foo50.Foo102.Foo205) \/ (Foo0.Foo2.Foo5.Foo11.Foo24.Foo50.Foo102.Foo206))))) \/ (((((Foo0.Foo2.Foo5.Foo12.Foo25.Foo51.Foo103.Foo207) \/ (Foo0.Foo2.Foo5.Foo12.Foo25.Foo51.Foo103.Foo208)) \/ ((Foo0.Foo2.Foo5.Foo12.Foo25.Foo51.Foo104.Foo209) \/ (Foo0.Foo2.Foo5.Foo12.Foo25.Foo51.Foo104.Foo210))) \/ (((Foo0.Foo2.Foo5.Foo12.Foo25.Foo52.Foo105.Foo211) \/ (Foo0.Foo2.Foo5.Foo12.Foo25.Foo52.Foo105.Foo212)) \/ ((Foo0.Foo2.Foo5.Foo12.Foo25.Foo52.Foo106.Foo213) \/ (Foo0.Foo2.Foo5.Foo12.Foo25.Foo52.Foo106.Foo214)))) \/ ((((Foo0.Foo2.Foo5.Foo12.Foo26.Foo53.Foo107.Foo215) \/ (Foo0.Foo2.Foo5.Foo12.Foo26.Foo53.Foo107.Foo216)) \/ ((Foo0.Foo2.Foo5.Foo12.Foo26.Foo53.Foo108.Foo217) \/ (Foo0.Foo2.Foo5.Foo12.Foo26.Foo53.Foo108.Foo218))) \/ (((Foo0.Foo2.Foo5.Foo12.Foo26.Foo54.Foo109.Foo219) \/ (Foo0.Foo2.Foo5.Foo12.Foo26.Foo54.Foo109.Foo220)) \/ ((Foo0.Foo2.Foo5.Foo12.Foo26.Foo54.Foo110.Foo221) \/ (Foo0.Foo2.Foo5.Foo12.Foo26.Foo54.Foo110.Foo222)))))) \/ ((((((Foo0.Foo2.Foo6.Foo13.Foo27.Foo55.Foo111.Foo223) \/ (Foo0.Foo2.Foo6.Foo13.Foo27.Foo55.Foo111.Foo224)) \/ ((Foo0.Foo2.Foo6.Foo13.Foo27.Foo55.Foo112.Foo225) \/ (Foo0.Foo2.Foo6.Foo13.Foo27.Foo55.Foo112.Foo226))) \/ (((Foo0.Foo2.Foo6.Foo13.Foo27.Foo56.Foo113.Foo227) \/ (Foo0.Foo2.Foo6.Foo13.Foo27.Foo56.Foo113.Foo228)) \/ ((Foo0.Foo2.Foo6.Foo13.Foo27.Foo56.Foo114.Foo229) \/ (Foo0.Foo2.Foo6.Foo13.Foo27.Foo56.Foo114.Foo230)))) \/ ((((Foo0.Foo2.Foo6.Foo13.Foo28.Foo57.Foo115.Foo231) \/ (Foo0.Foo2.Foo6.Foo13.Foo28.Foo57.Foo115.Foo232)) \/ ((Foo0.Foo2.Foo6.Foo13.Foo28.Foo57.Foo116.Foo233) \/ (Foo0.Foo2.Foo6.Foo13.Foo28.Foo57.Foo116.Foo234))) \/ (((Foo0.Foo2.Foo6.Foo13.Foo28.Foo58.Foo117.Foo235) \/ (Foo0.Foo2.Foo6.Foo13.Foo28.Foo58.Foo117.Foo236)) \/ ((Foo0.Foo2.Foo6.Foo13.Foo28.Foo58.Foo118.Foo237) \/ (Foo0.Foo2.Foo6.Foo13.Foo28.Foo58.Foo118.Foo238))))) \/ (((((Foo0.Foo2.Foo6.Foo14.Foo29.Foo59.Foo119.Foo239) \/ (Foo0.Foo2.Foo6.Foo14.Foo29.Foo59.Foo119.Foo240)) \/ ((Foo0.Foo2.Foo6.Foo14.Foo29.Foo59.Foo120.Foo241) \/ (Foo0.Foo2.Foo6.Foo14.Foo29.Foo59.Foo120.Foo242))) \/ (((Foo0.Foo2.Foo6.Foo14.Foo29.Foo60.Foo121.Foo243) \/ (Foo0.Foo2.Foo6.Foo14.Foo29.Foo60.Foo121.Foo244)) \/ ((Foo0.Foo2.Foo6.Foo14.Foo29.Foo60.Foo122.Foo245) \/ (Foo0.Foo2.Foo6.Foo14.Foo29.Foo60.Foo122.Foo246)))) \/ ((((Foo0.Foo2.Foo6.Foo14.Foo30.Foo61.Foo123.Foo247) \/ (Foo0.Foo2.Foo6.Foo14.Foo30.Foo61.Foo123.Foo248)) \/ ((Foo0.Foo2.Foo6.Foo14.Foo30.Foo61.Foo124.Foo249) \/ (Foo0.Foo2.Foo6.Foo14.Foo30.Foo61.Foo124.Foo250))) \/ (((Foo0.Foo2.Foo6.Foo14.Foo30.Foo62.Foo125.Foo251) \/ (Foo0.Foo2.Foo6.Foo14.Foo30.Foo62.Foo125.Foo252)) \/ ((Foo0.Foo2.Foo6.Foo14.Foo30.Foo62.Foo126.Foo253) \/ (Foo0.Foo2.Foo6.Foo14.Foo30.Foo62.Foo126.Foo254)))))))) @*)
  = match f () with
 | _ -> ()
 | effect Foo0 k -> 
 continue k (fun () -> if true then perform Foo1() else perform Foo2 ())
 | effect Foo1 k -> 
 continue k (fun () -> if true then perform Foo3() else perform Foo4 ())
 | effect Foo2 k -> 
 continue k (fun () -> if true then perform Foo5() else perform Foo6 ())
 | effect Foo3 k -> 
 continue k (fun () -> if true then perform Foo7() else perform Foo8 ())
 | effect Foo4 k -> 
 continue k (fun () -> if true then perform Foo9() else perform Foo10 ())
 | effect Foo5 k -> 
 continue k (fun () -> if true then perform Foo11() else perform Foo12 ())
 | effect Foo6 k -> 
 continue k (fun () -> if true then perform Foo13() else perform Foo14 ())
 | effect Foo7 k -> 
 continue k (fun () -> if true then perform Foo15() else perform Foo16 ())
 | effect Foo8 k -> 
 continue k (fun () -> if true then perform Foo17() else perform Foo18 ())
 | effect Foo9 k -> 
 continue k (fun () -> if true then perform Foo19() else perform Foo20 ())
 | effect Foo10 k -> 
 continue k (fun () -> if true then perform Foo21() else perform Foo22 ())
 | effect Foo11 k -> 
 continue k (fun () -> if true then perform Foo23() else perform Foo24 ())
 | effect Foo12 k -> 
 continue k (fun () -> if true then perform Foo25() else perform Foo26 ())
 | effect Foo13 k -> 
 continue k (fun () -> if true then perform Foo27() else perform Foo28 ())
 | effect Foo14 k -> 
 continue k (fun () -> if true then perform Foo29() else perform Foo30 ())
 | effect Foo15 k -> 
 continue k (fun () -> if true then perform Foo31() else perform Foo32 ())
 | effect Foo16 k -> 
 continue k (fun () -> if true then perform Foo33() else perform Foo34 ())
 | effect Foo17 k -> 
 continue k (fun () -> if true then perform Foo35() else perform Foo36 ())
 | effect Foo18 k -> 
 continue k (fun () -> if true then perform Foo37() else perform Foo38 ())
 | effect Foo19 k -> 
 continue k (fun () -> if true then perform Foo39() else perform Foo40 ())
 | effect Foo20 k -> 
 continue k (fun () -> if true then perform Foo41() else perform Foo42 ())
 | effect Foo21 k -> 
 continue k (fun () -> if true then perform Foo43() else perform Foo44 ())
 | effect Foo22 k -> 
 continue k (fun () -> if true then perform Foo45() else perform Foo46 ())
 | effect Foo23 k -> 
 continue k (fun () -> if true then perform Foo47() else perform Foo48 ())
 | effect Foo24 k -> 
 continue k (fun () -> if true then perform Foo49() else perform Foo50 ())
 | effect Foo25 k -> 
 continue k (fun () -> if true then perform Foo51() else perform Foo52 ())
 | effect Foo26 k -> 
 continue k (fun () -> if true then perform Foo53() else perform Foo54 ())
 | effect Foo27 k -> 
 continue k (fun () -> if true then perform Foo55() else perform Foo56 ())
 | effect Foo28 k -> 
 continue k (fun () -> if true then perform Foo57() else perform Foo58 ())
 | effect Foo29 k -> 
 continue k (fun () -> if true then perform Foo59() else perform Foo60 ())
 | effect Foo30 k -> 
 continue k (fun () -> if true then perform Foo61() else perform Foo62 ())
 | effect Foo31 k -> 
 continue k (fun () -> if true then perform Foo63() else perform Foo64 ())
 | effect Foo32 k -> 
 continue k (fun () -> if true then perform Foo65() else perform Foo66 ())
 | effect Foo33 k -> 
 continue k (fun () -> if true then perform Foo67() else perform Foo68 ())
 | effect Foo34 k -> 
 continue k (fun () -> if true then perform Foo69() else perform Foo70 ())
 | effect Foo35 k -> 
 continue k (fun () -> if true then perform Foo71() else perform Foo72 ())
 | effect Foo36 k -> 
 continue k (fun () -> if true then perform Foo73() else perform Foo74 ())
 | effect Foo37 k -> 
 continue k (fun () -> if true then perform Foo75() else perform Foo76 ())
 | effect Foo38 k -> 
 continue k (fun () -> if true then perform Foo77() else perform Foo78 ())
 | effect Foo39 k -> 
 continue k (fun () -> if true then perform Foo79() else perform Foo80 ())
 | effect Foo40 k -> 
 continue k (fun () -> if true then perform Foo81() else perform Foo82 ())
 | effect Foo41 k -> 
 continue k (fun () -> if true then perform Foo83() else perform Foo84 ())
 | effect Foo42 k -> 
 continue k (fun () -> if true then perform Foo85() else perform Foo86 ())
 | effect Foo43 k -> 
 continue k (fun () -> if true then perform Foo87() else perform Foo88 ())
 | effect Foo44 k -> 
 continue k (fun () -> if true then perform Foo89() else perform Foo90 ())
 | effect Foo45 k -> 
 continue k (fun () -> if true then perform Foo91() else perform Foo92 ())
 | effect Foo46 k -> 
 continue k (fun () -> if true then perform Foo93() else perform Foo94 ())
 | effect Foo47 k -> 
 continue k (fun () -> if true then perform Foo95() else perform Foo96 ())
 | effect Foo48 k -> 
 continue k (fun () -> if true then perform Foo97() else perform Foo98 ())
 | effect Foo49 k -> 
 continue k (fun () -> if true then perform Foo99() else perform Foo100 ())
 | effect Foo50 k -> 
 continue k (fun () -> if true then perform Foo101() else perform Foo102 ())
 | effect Foo51 k -> 
 continue k (fun () -> if true then perform Foo103() else perform Foo104 ())
 | effect Foo52 k -> 
 continue k (fun () -> if true then perform Foo105() else perform Foo106 ())
 | effect Foo53 k -> 
 continue k (fun () -> if true then perform Foo107() else perform Foo108 ())
 | effect Foo54 k -> 
 continue k (fun () -> if true then perform Foo109() else perform Foo110 ())
 | effect Foo55 k -> 
 continue k (fun () -> if true then perform Foo111() else perform Foo112 ())
 | effect Foo56 k -> 
 continue k (fun () -> if true then perform Foo113() else perform Foo114 ())
 | effect Foo57 k -> 
 continue k (fun () -> if true then perform Foo115() else perform Foo116 ())
 | effect Foo58 k -> 
 continue k (fun () -> if true then perform Foo117() else perform Foo118 ())
 | effect Foo59 k -> 
 continue k (fun () -> if true then perform Foo119() else perform Foo120 ())
 | effect Foo60 k -> 
 continue k (fun () -> if true then perform Foo121() else perform Foo122 ())
 | effect Foo61 k -> 
 continue k (fun () -> if true then perform Foo123() else perform Foo124 ())
 | effect Foo62 k -> 
 continue k (fun () -> if true then perform Foo125() else perform Foo126 ())
 | effect Foo63 k -> 
 continue k (fun () -> if true then perform Foo127() else perform Foo128 ())
 | effect Foo64 k -> 
 continue k (fun () -> if true then perform Foo129() else perform Foo130 ())
 | effect Foo65 k -> 
 continue k (fun () -> if true then perform Foo131() else perform Foo132 ())
 | effect Foo66 k -> 
 continue k (fun () -> if true then perform Foo133() else perform Foo134 ())
 | effect Foo67 k -> 
 continue k (fun () -> if true then perform Foo135() else perform Foo136 ())
 | effect Foo68 k -> 
 continue k (fun () -> if true then perform Foo137() else perform Foo138 ())
 | effect Foo69 k -> 
 continue k (fun () -> if true then perform Foo139() else perform Foo140 ())
 | effect Foo70 k -> 
 continue k (fun () -> if true then perform Foo141() else perform Foo142 ())
 | effect Foo71 k -> 
 continue k (fun () -> if true then perform Foo143() else perform Foo144 ())
 | effect Foo72 k -> 
 continue k (fun () -> if true then perform Foo145() else perform Foo146 ())
 | effect Foo73 k -> 
 continue k (fun () -> if true then perform Foo147() else perform Foo148 ())
 | effect Foo74 k -> 
 continue k (fun () -> if true then perform Foo149() else perform Foo150 ())
 | effect Foo75 k -> 
 continue k (fun () -> if true then perform Foo151() else perform Foo152 ())
 | effect Foo76 k -> 
 continue k (fun () -> if true then perform Foo153() else perform Foo154 ())
 | effect Foo77 k -> 
 continue k (fun () -> if true then perform Foo155() else perform Foo156 ())
 | effect Foo78 k -> 
 continue k (fun () -> if true then perform Foo157() else perform Foo158 ())
 | effect Foo79 k -> 
 continue k (fun () -> if true then perform Foo159() else perform Foo160 ())
 | effect Foo80 k -> 
 continue k (fun () -> if true then perform Foo161() else perform Foo162 ())
 | effect Foo81 k -> 
 continue k (fun () -> if true then perform Foo163() else perform Foo164 ())
 | effect Foo82 k -> 
 continue k (fun () -> if true then perform Foo165() else perform Foo166 ())
 | effect Foo83 k -> 
 continue k (fun () -> if true then perform Foo167() else perform Foo168 ())
 | effect Foo84 k -> 
 continue k (fun () -> if true then perform Foo169() else perform Foo170 ())
 | effect Foo85 k -> 
 continue k (fun () -> if true then perform Foo171() else perform Foo172 ())
 | effect Foo86 k -> 
 continue k (fun () -> if true then perform Foo173() else perform Foo174 ())
 | effect Foo87 k -> 
 continue k (fun () -> if true then perform Foo175() else perform Foo176 ())
 | effect Foo88 k -> 
 continue k (fun () -> if true then perform Foo177() else perform Foo178 ())
 | effect Foo89 k -> 
 continue k (fun () -> if true then perform Foo179() else perform Foo180 ())
 | effect Foo90 k -> 
 continue k (fun () -> if true then perform Foo181() else perform Foo182 ())
 | effect Foo91 k -> 
 continue k (fun () -> if true then perform Foo183() else perform Foo184 ())
 | effect Foo92 k -> 
 continue k (fun () -> if true then perform Foo185() else perform Foo186 ())
 | effect Foo93 k -> 
 continue k (fun () -> if true then perform Foo187() else perform Foo188 ())
 | effect Foo94 k -> 
 continue k (fun () -> if true then perform Foo189() else perform Foo190 ())
 | effect Foo95 k -> 
 continue k (fun () -> if true then perform Foo191() else perform Foo192 ())
 | effect Foo96 k -> 
 continue k (fun () -> if true then perform Foo193() else perform Foo194 ())
 | effect Foo97 k -> 
 continue k (fun () -> if true then perform Foo195() else perform Foo196 ())
 | effect Foo98 k -> 
 continue k (fun () -> if true then perform Foo197() else perform Foo198 ())
 | effect Foo99 k -> 
 continue k (fun () -> if true then perform Foo199() else perform Foo200 ())
 | effect Foo100 k -> 
 continue k (fun () -> if true then perform Foo201() else perform Foo202 ())
 | effect Foo101 k -> 
 continue k (fun () -> if true then perform Foo203() else perform Foo204 ())
 | effect Foo102 k -> 
 continue k (fun () -> if true then perform Foo205() else perform Foo206 ())
 | effect Foo103 k -> 
 continue k (fun () -> if true then perform Foo207() else perform Foo208 ())
 | effect Foo104 k -> 
 continue k (fun () -> if true then perform Foo209() else perform Foo210 ())
 | effect Foo105 k -> 
 continue k (fun () -> if true then perform Foo211() else perform Foo212 ())
 | effect Foo106 k -> 
 continue k (fun () -> if true then perform Foo213() else perform Foo214 ())
 | effect Foo107 k -> 
 continue k (fun () -> if true then perform Foo215() else perform Foo216 ())
 | effect Foo108 k -> 
 continue k (fun () -> if true then perform Foo217() else perform Foo218 ())
 | effect Foo109 k -> 
 continue k (fun () -> if true then perform Foo219() else perform Foo220 ())
 | effect Foo110 k -> 
 continue k (fun () -> if true then perform Foo221() else perform Foo222 ())
 | effect Foo111 k -> 
 continue k (fun () -> if true then perform Foo223() else perform Foo224 ())
 | effect Foo112 k -> 
 continue k (fun () -> if true then perform Foo225() else perform Foo226 ())
 | effect Foo113 k -> 
 continue k (fun () -> if true then perform Foo227() else perform Foo228 ())
 | effect Foo114 k -> 
 continue k (fun () -> if true then perform Foo229() else perform Foo230 ())
 | effect Foo115 k -> 
 continue k (fun () -> if true then perform Foo231() else perform Foo232 ())
 | effect Foo116 k -> 
 continue k (fun () -> if true then perform Foo233() else perform Foo234 ())
 | effect Foo117 k -> 
 continue k (fun () -> if true then perform Foo235() else perform Foo236 ())
 | effect Foo118 k -> 
 continue k (fun () -> if true then perform Foo237() else perform Foo238 ())
 | effect Foo119 k -> 
 continue k (fun () -> if true then perform Foo239() else perform Foo240 ())
 | effect Foo120 k -> 
 continue k (fun () -> if true then perform Foo241() else perform Foo242 ())
 | effect Foo121 k -> 
 continue k (fun () -> if true then perform Foo243() else perform Foo244 ())
 | effect Foo122 k -> 
 continue k (fun () -> if true then perform Foo245() else perform Foo246 ())
 | effect Foo123 k -> 
 continue k (fun () -> if true then perform Foo247() else perform Foo248 ())
 | effect Foo124 k -> 
 continue k (fun () -> if true then perform Foo249() else perform Foo250 ())
 | effect Foo125 k -> 
 continue k (fun () -> if true then perform Foo251() else perform Foo252 ())
 | effect Foo126 k -> 
 continue k (fun () -> if true then perform Foo253() else perform Foo254 ())
 | effect Foo127 k ->  continue k (fun () -> ())
 | effect Foo128 k ->  continue k (fun () -> ())
 | effect Foo129 k ->  continue k (fun () -> ())
 | effect Foo130 k ->  continue k (fun () -> ())
 | effect Foo131 k ->  continue k (fun () -> ())
 | effect Foo132 k ->  continue k (fun () -> ())
 | effect Foo133 k ->  continue k (fun () -> ())
 | effect Foo134 k ->  continue k (fun () -> ())
 | effect Foo135 k ->  continue k (fun () -> ())
 | effect Foo136 k ->  continue k (fun () -> ())
 | effect Foo137 k ->  continue k (fun () -> ())
 | effect Foo138 k ->  continue k (fun () -> ())
 | effect Foo139 k ->  continue k (fun () -> ())
 | effect Foo140 k ->  continue k (fun () -> ())
 | effect Foo141 k ->  continue k (fun () -> ())
 | effect Foo142 k ->  continue k (fun () -> ())
 | effect Foo143 k ->  continue k (fun () -> ())
 | effect Foo144 k ->  continue k (fun () -> ())
 | effect Foo145 k ->  continue k (fun () -> ())
 | effect Foo146 k ->  continue k (fun () -> ())
 | effect Foo147 k ->  continue k (fun () -> ())
 | effect Foo148 k ->  continue k (fun () -> ())
 | effect Foo149 k ->  continue k (fun () -> ())
 | effect Foo150 k ->  continue k (fun () -> ())
 | effect Foo151 k ->  continue k (fun () -> ())
 | effect Foo152 k ->  continue k (fun () -> ())
 | effect Foo153 k ->  continue k (fun () -> ())
 | effect Foo154 k ->  continue k (fun () -> ())
 | effect Foo155 k ->  continue k (fun () -> ())
 | effect Foo156 k ->  continue k (fun () -> ())
 | effect Foo157 k ->  continue k (fun () -> ())
 | effect Foo158 k ->  continue k (fun () -> ())
 | effect Foo159 k ->  continue k (fun () -> ())
 | effect Foo160 k ->  continue k (fun () -> ())
 | effect Foo161 k ->  continue k (fun () -> ())
 | effect Foo162 k ->  continue k (fun () -> ())
 | effect Foo163 k ->  continue k (fun () -> ())
 | effect Foo164 k ->  continue k (fun () -> ())
 | effect Foo165 k ->  continue k (fun () -> ())
 | effect Foo166 k ->  continue k (fun () -> ())
 | effect Foo167 k ->  continue k (fun () -> ())
 | effect Foo168 k ->  continue k (fun () -> ())
 | effect Foo169 k ->  continue k (fun () -> ())
 | effect Foo170 k ->  continue k (fun () -> ())
 | effect Foo171 k ->  continue k (fun () -> ())
 | effect Foo172 k ->  continue k (fun () -> ())
 | effect Foo173 k ->  continue k (fun () -> ())
 | effect Foo174 k ->  continue k (fun () -> ())
 | effect Foo175 k ->  continue k (fun () -> ())
 | effect Foo176 k ->  continue k (fun () -> ())
 | effect Foo177 k ->  continue k (fun () -> ())
 | effect Foo178 k ->  continue k (fun () -> ())
 | effect Foo179 k ->  continue k (fun () -> ())
 | effect Foo180 k ->  continue k (fun () -> ())
 | effect Foo181 k ->  continue k (fun () -> ())
 | effect Foo182 k ->  continue k (fun () -> ())
 | effect Foo183 k ->  continue k (fun () -> ())
 | effect Foo184 k ->  continue k (fun () -> ())
 | effect Foo185 k ->  continue k (fun () -> ())
 | effect Foo186 k ->  continue k (fun () -> ())
 | effect Foo187 k ->  continue k (fun () -> ())
 | effect Foo188 k ->  continue k (fun () -> ())
 | effect Foo189 k ->  continue k (fun () -> ())
 | effect Foo190 k ->  continue k (fun () -> ())
 | effect Foo191 k ->  continue k (fun () -> ())
 | effect Foo192 k ->  continue k (fun () -> ())
 | effect Foo193 k ->  continue k (fun () -> ())
 | effect Foo194 k ->  continue k (fun () -> ())
 | effect Foo195 k ->  continue k (fun () -> ())
 | effect Foo196 k ->  continue k (fun () -> ())
 | effect Foo197 k ->  continue k (fun () -> ())
 | effect Foo198 k ->  continue k (fun () -> ())
 | effect Foo199 k ->  continue k (fun () -> ())
 | effect Foo200 k ->  continue k (fun () -> ())
 | effect Foo201 k ->  continue k (fun () -> ())
 | effect Foo202 k ->  continue k (fun () -> ())
 | effect Foo203 k ->  continue k (fun () -> ())
 | effect Foo204 k ->  continue k (fun () -> ())
 | effect Foo205 k ->  continue k (fun () -> ())
 | effect Foo206 k ->  continue k (fun () -> ())
 | effect Foo207 k ->  continue k (fun () -> ())
 | effect Foo208 k ->  continue k (fun () -> ())
 | effect Foo209 k ->  continue k (fun () -> ())
 | effect Foo210 k ->  continue k (fun () -> ())
 | effect Foo211 k ->  continue k (fun () -> ())
 | effect Foo212 k ->  continue k (fun () -> ())
 | effect Foo213 k ->  continue k (fun () -> ())
 | effect Foo214 k ->  continue k (fun () -> ())
 | effect Foo215 k ->  continue k (fun () -> ())
 | effect Foo216 k ->  continue k (fun () -> ())
 | effect Foo217 k ->  continue k (fun () -> ())
 | effect Foo218 k ->  continue k (fun () -> ())
 | effect Foo219 k ->  continue k (fun () -> ())
 | effect Foo220 k ->  continue k (fun () -> ())
 | effect Foo221 k ->  continue k (fun () -> ())
 | effect Foo222 k ->  continue k (fun () -> ())
 | effect Foo223 k ->  continue k (fun () -> ())
 | effect Foo224 k ->  continue k (fun () -> ())
 | effect Foo225 k ->  continue k (fun () -> ())
 | effect Foo226 k ->  continue k (fun () -> ())
 | effect Foo227 k ->  continue k (fun () -> ())
 | effect Foo228 k ->  continue k (fun () -> ())
 | effect Foo229 k ->  continue k (fun () -> ())
 | effect Foo230 k ->  continue k (fun () -> ())
 | effect Foo231 k ->  continue k (fun () -> ())
 | effect Foo232 k ->  continue k (fun () -> ())
 | effect Foo233 k ->  continue k (fun () -> ())
 | effect Foo234 k ->  continue k (fun () -> ())
 | effect Foo235 k ->  continue k (fun () -> ())
 | effect Foo236 k ->  continue k (fun () -> ())
 | effect Foo237 k ->  continue k (fun () -> ())
 | effect Foo238 k ->  continue k (fun () -> ())
 | effect Foo239 k ->  continue k (fun () -> ())
 | effect Foo240 k ->  continue k (fun () -> ())
 | effect Foo241 k ->  continue k (fun () -> ())
 | effect Foo242 k ->  continue k (fun () -> ())
 | effect Foo243 k ->  continue k (fun () -> ())
 | effect Foo244 k ->  continue k (fun () -> ())
 | effect Foo245 k ->  continue k (fun () -> ())
 | effect Foo246 k ->  continue k (fun () -> ())
 | effect Foo247 k ->  continue k (fun () -> ())
 | effect Foo248 k ->  continue k (fun () -> ())
 | effect Foo249 k ->  continue k (fun () -> ())
 | effect Foo250 k ->  continue k (fun () -> ())
 | effect Foo251 k ->  continue k (fun () -> ())
 | effect Foo252 k ->  continue k (fun () -> ())
 | effect Foo253 k ->  continue k (fun () -> ())
 | effect Foo254 k ->  continue k (fun () -> ())