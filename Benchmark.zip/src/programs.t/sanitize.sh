#!/bin/bash

grep -v Time